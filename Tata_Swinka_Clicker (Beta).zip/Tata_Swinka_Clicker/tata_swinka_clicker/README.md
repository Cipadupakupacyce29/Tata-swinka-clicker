# Tata Świnka Clicker 🎮

Prosta gra typu "clicker" w przeglądarce.

## Jak uruchomić
1. Rozpakuj folder.
2. Otwórz `index.html` w przeglądarce (Chrome/Edge/Opera).
   - Jeśli audio nie działa po otwarciu, kliknij raz w przycisk `CLICK` (przeglądarki wymagają interakcji użytkownika).

## Sterowanie
- Klikaj przycisk **CLICK** aby zdobywać punkty.
- **Ulepszenia** (prawy górny róg):
  - **Double Click**: każde kliknięcie dodaje +2.
  - **Autoclicker**: automatycznie dodaje punkty co 1 sekundę.
- Po zdobyciu **999 punktów** wyświetla się ekran wygranej i odtwarza dźwięk 2, a licznik resetuje się.

## Pliki assetów
W folderze `assets/`:
- `bg.png` – tło (obraz 1)
- `win.png` – ekran wygranej (obraz 2)
- `icon.png` – ikona aplikacji (obraz 3)
- `click.m4a` – dźwięk kliknięcia (dźwięk 1)
- `win.mp3` – dźwięk wygranej (dźwięk 2)
